package GUI;

import javax.swing.*;

public interface ScreenProperties {

    ImageIcon getImageIcon();

    String getName();

    String getTitle();

}
