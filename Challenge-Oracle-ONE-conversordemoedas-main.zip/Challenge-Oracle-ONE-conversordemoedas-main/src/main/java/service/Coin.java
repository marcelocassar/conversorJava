package service;

public class Coin {
    private String code;
    private String codein;
    private String name;
    private double high;
    private double low;
    private double varBid;
    private double pctChange;
    private double bid;
    private double ask;
    private String timestamp;
    private String create_date;

    public String getCode() {
        return code;
    }

    public double getBid() {
        return bid;
    }
}
